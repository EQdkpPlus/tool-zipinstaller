<?php 
echo "Great! It works!";
?>